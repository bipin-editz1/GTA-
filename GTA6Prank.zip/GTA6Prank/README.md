# GTA VI – Prank App (Android)

Tiny, zero-dependency Android app (Java, no AndroidX). Splash -> animated prank screen -> "Close App".
No permissions, no internet, no data collected.

## APK banane ka tareeka (Android Studio)

1. Android Studio (Koala 2024.1+ recommended) install karo.
2. `File > Open` -> yeh `GTA6Prank` folder select karo. Gradle sync apne aap hoga
   (pehli baar internet chahiye - Gradle 8.7 + Android Gradle Plugin download hoga).
   Agar JDK ka error aaye: `Settings > Build Tools > Gradle > Gradle JDK` = 17 (jbr-17).
3. **Quick APK (install karke dost ko bhejne ke liye):**
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   Output: `app/build/outputs/apk/debug/app-debug.apk`
4. **Final signed release APK (chhota size, recommended):**
   `Build > Generate Signed App Bundle / APK > APK > Create new...` (keystore banao, password yaad rakho)
   -> `release` select karo -> V1 + V2 tick -> Finish.
   Output: `app/release/app-release.apk`

## Command line (optional)
```
./gradlew assembleDebug          # debug APK
```
(Agar `gradlew` file na ho to Android Studio me ek baar project open karo, ya system Gradle se `gradle wrapper` chalao.)

## Phone par install
APK ko phone me copy karo -> tap karo -> "Install unknown apps" allow karo -> Install.

## Customise
- Texts: `app/src/main/res/values/strings.xml`
- Colors: `app/src/main/res/values/colors.xml`
- Animations: `app/src/main/java/com/badex/gtavi/MainActivity.java`
- Icon: `res/mipmap-*` + `res/drawable-nodpi/ic_launcher_*.png` (tumhari photo se auto-generate hua hai)
- Package/App ID: `com.badex.gtavi` (`app/build.gradle`)
