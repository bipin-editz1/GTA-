package com.badex.gtavi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.OvershootInterpolator;

public class SplashActivity extends Activity {

    private static final long SPLASH_MS = 2000;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable goNext = new Runnable() {
        @Override public void run() {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        View logo = findViewById(R.id.splashLogo);
        View title = findViewById(R.id.splashTitle);
        View tagline = findViewById(R.id.splashTagline);

        logo.setAlpha(0f);
        logo.setScaleX(0.5f);
        logo.setScaleY(0.5f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(800).setInterpolator(new OvershootInterpolator(1.6f)).start();

        title.setAlpha(0f);
        title.setTranslationY(48f);
        title.animate().alpha(1f).translationY(0f)
                .setStartDelay(350).setDuration(600).start();

        tagline.setAlpha(0f);
        tagline.animate().alpha(1f).setStartDelay(800).setDuration(600).start();

        handler.postDelayed(goNext, SPLASH_MS);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(goNext);
        super.onDestroy();
    }
}
