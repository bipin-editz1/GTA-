package com.badex.gtavi;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ObjectAnimator wobble;
    private ObjectAnimator pulse;
    private TextView tvEmoji, tvLine1, tvLine2, tvLine3;
    private Button btnClose;

    private final Runnable shakeLoop = new Runnable() {
        @Override public void run() {
            ObjectAnimator.ofFloat(tvLine2, View.TRANSLATION_X,
                    0f, 26f, -26f, 16f, -16f, 7f, -7f, 0f).setDuration(550).start();
            handler.postDelayed(this, 2600);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvEmoji = findViewById(R.id.tvEmoji);
        tvLine1 = findViewById(R.id.tvLine1);
        tvLine2 = findViewById(R.id.tvLine2);
        tvLine3 = findViewById(R.id.tvLine3);
        btnClose = findViewById(R.id.btnClose);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                finishAndRemoveTask();
            }
        });

        // Neon gradient on the headline
        tvLine2.post(new Runnable() {
            @Override public void run() {
                float w = Math.max(1, tvLine2.getWidth());
                tvLine2.getPaint().setShader(new LinearGradient(0, 0, w, 0,
                        new int[]{getColor(R.color.neon_pink), getColor(R.color.neon_cyan)},
                        null, Shader.TileMode.CLAMP));
                tvLine2.invalidate();
            }
        });

        playEntrance();
    }

    private void playEntrance() {
        tvEmoji.setAlpha(0f); tvEmoji.setScaleX(0f); tvEmoji.setScaleY(0f);
        tvLine1.setAlpha(0f); tvLine1.setTranslationY(-200f);
        tvLine2.setAlpha(0f); tvLine2.setTranslationY(-900f);
        tvLine3.setAlpha(0f); tvLine3.setScaleX(0.6f); tvLine3.setScaleY(0.6f);
        btnClose.setAlpha(0f); btnClose.setTranslationY(120f);

        // 1) Clown pops in, then wobbles forever
        tvEmoji.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(700).setInterpolator(new OvershootInterpolator(3f))
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        tvEmoji.setRotation(-14f);
                        wobble = ObjectAnimator.ofFloat(tvEmoji, View.ROTATION, -14f, 14f);
                        wobble.setDuration(420);
                        wobble.setRepeatCount(ValueAnimator.INFINITE);
                        wobble.setRepeatMode(ValueAnimator.REVERSE);
                        wobble.setInterpolator(new AccelerateDecelerateInterpolator());
                        wobble.start();
                    }
                }).start();

        // 2) Label bounces in
        tvLine1.animate().alpha(1f).translationY(0f)
                .setStartDelay(350).setDuration(600)
                .setInterpolator(new BounceInterpolator()).start();

        // 3) Headline drops from the top, bounces, then shakes every few seconds
        tvLine2.animate().alpha(1f).translationY(0f)
                .setStartDelay(600).setDuration(1000)
                .setInterpolator(new BounceInterpolator())
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        handler.postDelayed(shakeLoop, 400);
                    }
                }).start();

        // 4) Sub text pops
        tvLine3.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(1300).setDuration(600)
                .setInterpolator(new OvershootInterpolator(2.5f)).start();

        // 5) Button rises, then gently pulses
        btnClose.animate().alpha(1f).translationY(0f)
                .setStartDelay(1700).setDuration(500)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        pulse = ObjectAnimator.ofPropertyValuesHolder(btnClose,
                                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.06f),
                                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.06f));
                        pulse.setDuration(800);
                        pulse.setRepeatCount(ValueAnimator.INFINITE);
                        pulse.setRepeatMode(ValueAnimator.REVERSE);
                        pulse.start();
                    }
                }).start();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (wobble != null) wobble.cancel();
        if (pulse != null) pulse.cancel();
        super.onDestroy();
    }
}
